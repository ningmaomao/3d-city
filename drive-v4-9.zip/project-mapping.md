# 主题大楼与线上项目对应表

来源：https://3d.legendning.com.cn/，核对日期：2026-10-26。

| 编号 | 主题大楼 | 原项目 | 入口 |
|---|---|---|---|
| 01 | 智慧股票馆 | 小智慧 · 股票 | https://stock.legendning.com.cn |
| 02 | 客户服务中心 | 客户工作台 · CRM星云 | https://crm.legendning.com.cn |
| 03 | 时间管理馆 | 定时提醒系统 | https://reminder.legendning.com.cn |
| 04 | 光影影院 | kvideo 影视播放系统 | https://bmw.legendning.com.cn |
| 05 | 柯南词汇馆 | 柯南词汇胶片卡片 | https://film.legendning.com.cn |
| 06 | 英语听力馆 | 英语听选测验 | https://www.legendning.com.cn |
| 07 | 英语词汇馆 | 英语词汇答题 | https://abc.legendning.com.cn |
| 08 | 工行题库馆 | ICBC 单选题 · 在线答题 | https://icbc.legendning.com.cn |
| 09 | 世界杯探索馆 | 域名世界杯探索 | https://first.legendning.com.cn |
| 10 | 健康管理馆 | Legend Ning · Smart Weight | https://apps.apple.com/us/app/legend-ning-smart-weight/id6756292767 |
| 11 | 魔方实验室 | 盲拧实验室 · Old Pochmann | https://legendning.com.cn/blindcube |
| 12 | 财税服务中心 | 个税计算工具 | http://tax.legendning.com.cn |
| 13 | 太极文化馆 | 太极 · 微信小程序 | 微信扫码：assets/miniprogram.png |
| 14 | 环球购物中心 | 全球好物 · Mini Shop | https://shop.legendning.com.cn |
