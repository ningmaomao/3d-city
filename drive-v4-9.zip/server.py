#!/usr/bin/env python3
"""Serve the driving project and copy selected audio files into its music folder."""
import argparse
import hashlib
import ipaddress
import json
import os
from pathlib import Path
import re
import tempfile
import threading
import unicodedata
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, quote, urlsplit

ROOT = Path(__file__).resolve().parent
MUSIC = ROOT / 'music'
AUDIO_EXTENSIONS = {'.mp3', '.wav', '.ogg', '.m4a', '.aac', '.flac', '.opus'}
MAX_UPLOAD = 200 * 1024 * 1024
MUSIC_LOCK = threading.Lock()


def audio_files():
    MUSIC.mkdir(exist_ok=True)
    return sorted((p for p in MUSIC.iterdir() if p.is_file() and not p.is_symlink()
                   and p.suffix.lower() in AUDIO_EXTENSIONS), key=lambda p: p.name.casefold())


def track(p):
    return {'name': p.stem, 'url': 'music/' + quote(p.name), 'file': p.name, 'saved': True}


def playlist(write=False):
    tracks = [track(p) for p in audio_files()]
    if write:
        temporary = MUSIC / '.playlist-new.json'
        temporary.write_text(json.dumps({'tracks': tracks}, ensure_ascii=False, indent=2), encoding='utf-8')
        os.replace(temporary, MUSIC / 'playlist.json')
    return tracks


def safe_filename(value):
    value = unicodedata.normalize('NFC', value.replace('\\', '/').split('/')[-1])
    value = re.sub(r'[<>:"/\\|?*\x00-\x1f]', '_', value).strip(' .')
    p = Path(value)
    if p.suffix.lower() not in AUDIO_EXTENSIONS or not p.stem:
        raise ValueError('请选择 MP3、WAV、OGG、M4A、AAC、FLAC 或 OPUS 音频文件。')
    stem = p.stem[:120].strip(' .')
    if re.fullmatch(r'(CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])', stem, re.I):
        stem = '_' + stem
    return stem + p.suffix.lower()


class Handler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(ROOT), **kwargs)

    def end_headers(self):
        self.send_header('X-Content-Type-Options', 'nosniff')
        super().end_headers()

    def send_json(self, code, value):
        raw = json.dumps(value, ensure_ascii=False).encode('utf-8')
        self.send_response(code)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Cache-Control', 'no-store')
        self.send_header('Content-Length', str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)

    def do_GET(self):
        if urlsplit(self.path).path == '/api/music':
            with MUSIC_LOCK:
                tracks = playlist(write=True)
            return self.send_json(200, {'tracks': tracks})
        return super().do_GET()

    def local_upload_allowed(self):
        try:
            host = urlsplit('http://' + self.headers.get('Host', '')).hostname
            if host not in {'localhost', '127.0.0.1', '::1'}:
                return False
            if not ipaddress.ip_address(self.client_address[0]).is_loopback:
                return False
            if any(self.headers.get(k) for k in ('Forwarded', 'X-Forwarded-For', 'X-Forwarded-Host')):
                return False
            origin = self.headers.get('Origin')
            return not origin or urlsplit(origin).netloc == self.headers.get('Host')
        except ValueError:
            return False

    def do_POST(self):
        parsed = urlsplit(self.path)
        if parsed.path != '/api/music/upload':
            return self.send_json(404, {'error': '未知接口。'})
        if not self.local_upload_allowed():
            return self.send_json(403, {'error': '请在本机 127.0.0.1 页面添加歌曲。'})
        temporary = None
        try:
            filename = safe_filename(parse_qs(parsed.query).get('name', [''])[0])
            length = int(self.headers.get('Content-Length', '0'))
            if length <= 0 or length > MAX_UPLOAD:
                return self.send_json(413, {'error': '歌曲不能为空，单个文件最大 200 MB。'})
            MUSIC.mkdir(exist_ok=True)
            digest = hashlib.sha256()
            with tempfile.NamedTemporaryFile(prefix='.upload-', suffix='.part', dir=MUSIC, delete=False) as output:
                temporary = Path(output.name)
                remaining = length
                while remaining:
                    chunk = self.rfile.read(min(1024 * 1024, remaining))
                    if not chunk:
                        raise ValueError('文件未完整传输，请重新添加。')
                    output.write(chunk)
                    digest.update(chunk)
                    remaining -= len(chunk)
            with MUSIC_LOCK:
                # Re-selecting the same audio does not create duplicate copies.
                duplicate = None
                for existing in audio_files():
                    if existing.stat().st_size == length:
                        h = hashlib.sha256()
                        with existing.open('rb') as source:
                            for block in iter(lambda: source.read(1024 * 1024), b''):
                                h.update(block)
                        if h.digest() == digest.digest():
                            duplicate = existing
                            break
                if duplicate:
                    target = duplicate
                else:
                    target = MUSIC / filename
                    n = 2
                    while target.exists():
                        target = MUSIC / (Path(filename).stem + ' (' + str(n) + ')' + Path(filename).suffix)
                        n += 1
                    os.replace(temporary, target)
                    temporary = None
                tracks = playlist(write=True)
            self.send_json(200, {'track': track(target), 'tracks': tracks, 'duplicate': duplicate is not None})
        except (ValueError, TypeError) as exc:
            self.send_json(400, {'error': str(exc)})
        except OSError:
            self.send_json(500, {'error': '保存失败，请检查 music 文件夹的写入权限和磁盘空间。'})
        finally:
            if temporary is not None:
                temporary.unlink(missing_ok=True)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--port', type=int, default=5088)
    parser.add_argument('--bind', default='127.0.0.1')
    args = parser.parse_args()
    with MUSIC_LOCK:
        playlist(write=True)
    try:
        server = ThreadingHTTPServer((args.bind, args.port), Handler)
    except OSError as exc:
        print('启动失败：端口可能被占用。请先在旧服务窗口按 Ctrl+C，再运行 py server.py。', flush=True)
        raise SystemExit(1) from exc
    print('LEGENDNING DRIVE: http://127.0.0.1:' + str(server.server_port), flush=True)
    print('Music files are saved in: ' + str(MUSIC), flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == '__main__':
    main()
